﻿using Abp.MultiTenancy;
using MicroServices.Authorization.Users;

namespace MicroServices.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}